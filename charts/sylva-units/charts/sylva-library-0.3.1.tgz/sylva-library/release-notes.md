# Merge Requests integrated in this release

## CI

* Update dependency renovate-bot/renovate-runner to v20.1.0 [!96](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/96) ~"renovate"

## Other

* canonical-k8s: add cabpck -> ck8s mapping for images [!94](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/94) 

## Contributors

[Adrian Vladu](https://gitlab.com/ader1990)
