# Merge Requests integrated in this release

## CI

* <details><summary>Update dependency renovate-bot/renovate-runner to v18.64.1</summary>

  * Update dependency renovate-bot/renovate-runner to v18.57.2 [#37](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/37) ~"CI" ~"renovate"

  * Update dependency renovate-bot/renovate-runner to v18.64.1 [#40](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/40) ~"CI" ~"renovate"
</details>


## Other

* introduce dict\_to\_key\_values\_separated\_string [#39](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/39) 

## Contributors

[francois klieber](https://gitlab.com/FrancoisKlieberOrange)
