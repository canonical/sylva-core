{{/*
This named template returns a cluster ip address based on the following conditions:

- .ip_preallocations.primary if bootstrap provider is a "cabpoa" and the cluster has only one node
- .cluster_virtual_ip for all other cases

It can be used in parent charts like:

    * `sylva-capi-cluster` with:
        {{ tuple .Values | include "getClusterVIP" }}

*/}}
{{- define "getClusterVIP" -}}
{{- $values := index . 0 -}}
    {{- $clusterVIP := $values.cluster_virtual_ip -}}
    {{- if and (eq $values.capi_providers.bootstrap_provider "cabpoa") (eq (len $values.baremetal_hosts) 1) -}}
      {{- range $bmh_name, $bmh_data := $values.baremetal_hosts -}}
        {{- $clusterVIP = (dig "ip_preallocations" "primary" $values.cluster_virtual_ip $bmh_data) -}}
        {{- break -}}
      {{- end -}}
    {{- end -}}
{{ $clusterVIP }}
{{- end -}}
