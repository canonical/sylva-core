# Merge Requests integrated in this release

## CAPO

* add os-image-pv-size-decompressed named template [!97](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/97) 

## Contributors

[Thomas Morin](https://gitlab.com/tmmorin)
