# Merge Requests integrated in this release

## Other

* Calculate interface mtu for non allocated interfaces and support vlan specific mtu [!104](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/104) 

## Contributors

[Cristian Manda](https://gitlab.com/cristian.manda)
