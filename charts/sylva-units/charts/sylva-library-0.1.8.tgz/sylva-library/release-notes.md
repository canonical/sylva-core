# Merge Requests integrated in this release

## CI

* <details><summary>Update dependency renovate-bot/renovate-runner to v18.96.7</summary>

  * Update dependency renovate-bot/renovate-runner to v18.89.2 [#56](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/56) ~"CI" ~"renovate"

  * Update dependency renovate-bot/renovate-runner to v18.96.5 [#60](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/60) ~"CI" ~"dependencies::minor" ~"renovate"

  * Update dependency renovate-bot/renovate-runner to v18.96.7 [#63](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/63) ~"CI" ~"dependencies::patch" ~"renovate"
</details>

* <details><summary>Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.29</summary>

  * Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.26 [#57](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/57) ~"CI" ~"renovate"

  * Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.27 [#58](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/58) ~"CI" ~"dependencies::patch" ~"renovate"

  * Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.28 [#61](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/61) ~"CI" ~"dependencies::patch" ~"renovate"

  * Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.29 [#62](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/62) ~"CI" ~"dependencies::patch" ~"renovate"
</details>


## Other

* Add VIP check for OKD single node cluster [#55](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/55) ~"okd"

## Contributors

[Jianzhu Zhang](https://gitlab.com/jianzzha)
