# Merge Requests integrated in this release

## CAPO

* OS images helpers: add find-cluster-image-selectors [!81](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/81) ~"capm3"

## CI

* <details><summary>Update dependency renovate-bot/renovate-runner to v20</summary>

  * Update dependency renovate-bot/renovate-runner to v19.111.4 [!91](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/91) ~"renovate"

  * Update dependency renovate-bot/renovate-runner to v20 [!92](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/92) ~"renovate"
</details>

* Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.37 [!93](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/93) ~"renovate"

## Contributors

[Thomas Morin](https://gitlab.com/tmmorin)
