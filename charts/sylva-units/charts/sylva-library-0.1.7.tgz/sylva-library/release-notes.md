# Merge Requests integrated in this release

## CI

* Update dependency renovate-bot/renovate-runner to v18.85.4 [#53](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/53) ~"CI" ~"renovate"

## Other

* Add apiVersion for AgentBootstrapConfigTemplate [#54](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/54) 

## Contributors

[Jianzhu Zhang](https://gitlab.com/jianzzha)
