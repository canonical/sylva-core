# Merge Requests integrated in this release

## Documentation

* Fix version syntax to allow testing uncommitted work [#28](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/28) ~"docs"

## CI

* Update quay.io/helmpack/chart-testing Docker tag to v3.11.0 [#19](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/19) ~"CI" ~"renovate"
* <details><summary>Update dependency renovate-bot/renovate-runner to v18.47.0</summary>

  * Update dependency renovate-bot/renovate-runner to v18.25.3 [#26](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/26) ~"CI" ~"renovate"

  * Update dependency renovate-bot/renovate-runner to v18.31.1 [#30](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/30) ~"CI" ~"renovate"

  * Update dependency renovate-bot/renovate-runner to v18.40.1 [#33](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/33) ~"CI" ~"renovate"

  * Update dependency renovate-bot/renovate-runner to v18.47.0 [#35](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/35) ~"CI" ~"renovate"
</details>

* <details><summary>Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.22</summary>

  * Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.19 [#29](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/29) ~"CI" ~"renovate"

  * Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.20 [#31](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/31) ~"CI" ~"renovate"

  * Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.21 [#32](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/32) ~"CI" ~"renovate"

  * Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.22 [#34](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/34) ~"CI" ~"renovate"
</details>


## Other

* Add home field in Chart.yaml [#36](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/36) ~"renovate::configuration"

## Contributors

[Bogdan-Adrian Burciu](https://gitlab.com/baburciu), [Loic Nicolle](https://gitlab.com/loic.nicolle)
