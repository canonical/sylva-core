{{/*
"registry_mirrors_auth_secret_name"

Computes the deterministic secret name for the registry auth secret.
The name includes a hash of the auth-bearing registries' config so that
changing credentials automatically produces a new secret name, which
forces a rolling update of the machine templates that reference it.

Usage:
  include "registry_mirrors_auth_secret_name" $envAll

Returns a string like: "<cluster-name>-registry-auth-<8-char-hash>"
*/}}
{{- define "registry_mirrors_auth_secret_name" -}}
  {{- $envAll := . -}}
  {{- $registryMirrors := get $envAll.Values "registry_mirrors" | default dict -}}
  {{- $authConfig := dict -}}
  {{- range $registry, $mirrors := get $registryMirrors "hosts_config" | default dict -}}
    {{- range $_, $config := $mirrors -}}
      {{- if get $config "auth" -}}
        {{- $_ := set $authConfig $registry $mirrors -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
  {{- printf "%s-registry-auth-%s" $envAll.Values.name ($authConfig | toJson | sha256sum | trunc 8) -}}
{{- end -}}

{{/*
"registry_mirrors_secret_data"

Renders the `data:` block of a Kubernetes Secret holding the full
hosts.toml content for every registry that has auth configured.

The key for each entry is the sanitized registry name (colons and dots
replaced with dashes so it is a valid Secret data key, which is also
used as the `key:` field in `contentFrom.secret`).

Usage:
  include "registry_mirrors_secret_data" $envAll
*/}}
{{- define "registry_mirrors_secret_data" -}}
  {{- $envAll := . -}}
  {{- $registryMirrors := get $envAll.Values "registry_mirrors" | default dict -}}
  {{- $defaultSettings := get $registryMirrors "default_settings" | default dict -}}
  {{- range $registry, $mirrors := get $registryMirrors "hosts_config" | default dict -}}
    {{- $hasAuth := false -}}
    {{- range $_, $config := $mirrors -}}
      {{- if get $config "auth" -}}
        {{- $hasAuth = true -}}
      {{- end -}}
    {{- end -}}
    {{- if $hasAuth -}}
      {{- $defaultMirror := printf "https://%s" $registry -}}
      {{- range $_, $config := $mirrors -}}
        {{- if get $config "is_default_mirror" -}}
          {{- $defaultMirror = $config.mirror_url -}}
        {{- end -}}
      {{- end -}}
      {{- /* Build the full hosts.toml content as a string */ -}}
      {{- $tomlContent := printf "server = \"%s\"\n" $defaultMirror -}}
      {{- range $_, $config := $mirrors -}}
        {{- $tomlContent = printf "%s[host.\"%s\"]\n" $tomlContent $config.mirror_url -}}
        {{- range $setting, $value := mergeOverwrite (deepCopy $defaultSettings) (get $config "registry_settings" | default dict) -}}
          {{- $tomlContent = printf "%s  %s = %s\n" $tomlContent $setting ($value | toJson) -}}
        {{- end -}}
        {{- if get $config "auth" -}}
          {{- $token := "" -}}
          {{- if $config.auth.token -}}
            {{- $token = $config.auth.token -}}
          {{- else -}}
            {{- $token = printf "%s:%s" $config.auth.username $config.auth.password | b64enc -}}
          {{- end -}}
          {{- $tomlContent = printf "%s[host.\"%s\".header]\n  Authorization = [\"Basic %s\"]\n" $tomlContent $config.mirror_url $token -}}
        {{- end -}}
      {{- end -}}
      {{- /* Sanitize registry name for use as a Secret data key */ -}}
      {{- $secretKey := $registry | replace ":" "-" | replace "." "-" }}
{{ $secretKey }}: {{ $tomlContent | b64enc -}}
    {{- end -}}
  {{- end -}}
{{- end -}}

{{/*
"registry_mirrors"

Renders CAPI machine template `files:` entries for containerd registry
mirror configuration.

  - For registries WITHOUT auth: renders an inline `content:` entry as
    before (no secret needed).
  - For registries WITH auth: renders a `contentFrom: secret:` entry
    that references the registry auth secret, keeping credentials out of
Renders files for containerd registry mirror configuration,
- either as CAPI machine template `files:` entries

  - For registries WITHOUT auth: renders an inline `content:` entry as
    before (no secret needed).
  - For registries WITH auth: renders a `contentFrom: secret:` entry
    that references the registry auth secret, keeping credentials out of
    the bootstrap resource spec.

- or as a shell script to generate config files for kind (used by sylva-core/tools/kind/bootstrap-cluster.sh)


Usage:
  include "registry_mirrors" (tuple $envAll $type)

  $type: "" for CAPI machine files (default), "kind" for KinD shell cmds
*/}}
{{- define "registry_mirrors" -}}
  {{- $envAll := index . 0 -}}
  {{- $type := index . 1 | default "" -}}
  {{- $index := 0 -}}
  {{- $registryMirrors := get $envAll.Values "registry_mirrors" | default dict -}}
  {{- $defaultSettings := get $registryMirrors "default_settings" | default dict -}}
  {{- $mirrorSettings := dict -}}
  {{- range $registry, $mirrors := get $registryMirrors "hosts_config" | default dict }}
    {{- $registryUrl := printf "https://%s" $registry }}
    {{- $defaultMirror := $registryUrl }}
    {{- $defaultMirrorFound := false }}
    {{- $hasAuth := false }}
    {{- range $_, $config := $mirrors }}
      {{- $mirrorSettings = set $mirrorSettings $config.mirror_url (mergeOverwrite (deepCopy $defaultSettings) (deepCopy (get $config "registry_settings" | default dict))) }}
      {{- if get $config "is_default_mirror" }}
          {{- if $defaultMirrorFound }}
            {{- fail (printf "Error: More than one default mirror found for registry '%s'" $registry) }}
          {{- end }}
          {{- $defaultMirror = $config.mirror_url }}
          {{- $defaultMirrorFound = true }}
      {{- end }}
      {{- if get $config "auth" }}
          {{- $hasAuth = true }}
      {{- end }}
    {{- end }}
    {{- if eq $type "kind" -}}
mkdir -p $KIND_CONFIG_DIRECTORY/{{ $registry }}
cat << EOF{{ $index }} > $KIND_CONFIG_DIRECTORY/{{ $registry }}/hosts.toml
server = "{{ $defaultMirror }}"
{{- if $defaultMirrorFound }}
  {{- range $setting, $value := get $mirrorSettings $defaultMirror }}
{{ $setting }} = {{ $value | toJson }}
  {{- end -}}
{{- end -}}
{{- range $_, $config := $mirrors }}
[host."{{ $config.mirror_url }}"]
{{- range $setting,$value := get $mirrorSettings $config.mirror_url }}
  {{ $setting }} = {{ $value | toJson }}
{{- end -}}
{{- if get $config "auth" }}
[host."{{ $config.mirror_url }}".header]
  Authorization = ["Basic {{ if $config.auth.token }}{{ $config.auth.token }}{{ else }}{{ printf "%s:%s" $config.auth.username $config.auth.password | b64enc }}{{ end }}"]
{{- end -}}
{{- end }}
EOF{{ $index }}
{{- println -}}
{{- $index = add1 $index -}}
    {{- else if $hasAuth -}}
      {{- /* Registry has auth: use contentFrom: secret: to keep credentials out of the bootstrap spec */ -}}
      {{- $secretName := include "registry_mirrors_auth_secret_name" $envAll -}}
      {{- $secretKey := $registry | replace ":" "-" | replace "." "-" }}
- path: /etc/containerd/registry.d/{{ $registry }}/hosts.toml
  owner: root
  permissions: "0644"
  contentFrom:
    secret:
      name: {{ $secretName }}
      key: {{ $secretKey }}
    {{- println "" }}
    {{- else -}}
      {{- /* Registry has no auth: keep inline content as before */ -}}
- path: /etc/containerd/registry.d/{{ $registry }}/hosts.toml
  owner: root
  permissions: "0644"
  content: |
    server = "{{ $defaultMirror }}"
    {{- if $defaultMirrorFound }}
      {{- range $setting, $value := get $mirrorSettings $defaultMirror }}
    {{ $setting }} = {{ $value | toJson }}
      {{- end -}}
    {{- end -}}
    {{- range $_, $config := $mirrors }}
    [host."{{ $config.mirror_url }}"]
    {{- range $setting,$value := get $mirrorSettings $config.mirror_url }}
      {{ $setting }} = {{ $value | toJson }}
    {{- end }}
    {{- end }}
    {{- end -}}
    {{- println "" }}
  {{- end -}}
{{- end -}}
