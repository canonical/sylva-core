# Merge Requests integrated in this release

1 merge request was integrated in this repo between 0.10.0 and 0.10.1.
These notes don't account for the MRs merged in secondary repos.

## Networking

* Add ipv6 support [\!158](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/158) 

## Contributors

1 person contributed.

[Cristian Manda](https://gitlab.com/cristian.manda)
