# Merge Requests integrated in this release

## Other

* rename transform\_dict\_to\_key\_values\_separated\_string.tpl to... [#41](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/41) 

## Contributors

[francois klieber](https://gitlab.com/FrancoisKlieberOrange)
