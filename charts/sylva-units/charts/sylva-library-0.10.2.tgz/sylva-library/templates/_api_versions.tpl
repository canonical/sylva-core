{{/*
This named template that defines apiVersion for some kind of resources
*/}}

{{- define "apiVersions" -}}
Cluster: cluster.x-k8s.io/v1beta2
MachineDeployment: cluster.x-k8s.io/v1beta2
MachinePool: cluster.x-k8s.io/v1beta2
KubeadmControlPlane: controlplane.cluster.x-k8s.io/v1beta2
KubeadmConfig: bootstrap.cluster.x-k8s.io/v1beta2
KubeadmConfigTemplate: bootstrap.cluster.x-k8s.io/v1beta2
RKE2ControlPlane: controlplane.cluster.x-k8s.io/v1beta2
RKE2Config: bootstrap.cluster.x-k8s.io/v1beta2
RKE2ConfigTemplate: bootstrap.cluster.x-k8s.io/v1beta2
OpenshiftAssistedControlPlane: controlplane.cluster.x-k8s.io/v1alpha3
OpenshiftAssistedConfig: bootstrap.cluster.x-k8s.io/v1alpha2
OpenshiftAssistedConfigTemplate: bootstrap.cluster.x-k8s.io/v1alpha2
CK8sControlPlane: controlplane.cluster.x-k8s.io/v1beta2
CK8sConfig: bootstrap.cluster.x-k8s.io/v1beta2
CK8sConfigTemplate: bootstrap.cluster.x-k8s.io/v1beta2
DockerCluster: infrastructure.cluster.x-k8s.io/v1beta2
DockerMachineTemplate: infrastructure.cluster.x-k8s.io/v1beta2
VSphereCluster: infrastructure.cluster.x-k8s.io/v1beta1
VSphereMachineTemplate: infrastructure.cluster.x-k8s.io/v1beta1
ONECluster: infrastructure.cluster.x-k8s.io/v1beta1
ONEMachineTemplate: infrastructure.cluster.x-k8s.io/v1beta1
OpenStackCluster: infrastructure.cluster.x-k8s.io/v1beta1
OpenStackMachineTemplate: infrastructure.cluster.x-k8s.io/v1beta1
Metal3Cluster: infrastructure.cluster.x-k8s.io/v1beta1
Metal3MachineTemplate: infrastructure.cluster.x-k8s.io/v1beta1
Metal3DataTemplate: infrastructure.cluster.x-k8s.io/v1beta1
BareMetalHost: metal3.io/v1alpha1
IPPool: ipam.metal3.io/v1alpha1
KubevirtCluster: infrastructure.cluster.x-k8s.io/v1alpha1
KubevirtMachineTemplate: infrastructure.cluster.x-k8s.io/v1alpha1
{{- end -}}

{{/*
This named template ease to add some resources from a helm chart using this one.
*/}}
{{- define "extendedApiVersions" -}}
{{- end -}}

{{/*
This named template returns the apiVersion for the resource passed in argument

Note: a failure is raised if resource is not declared in previous "apiVersions" named template

*/}}

{{- define "getApiVersion" -}}
{{- $key := . -}}
{{- $allApiVersions := (include "apiVersions" . |fromYaml) -}}
{{- $allApiVersions := mergeOverwrite $allApiVersions (include "extendedApiVersions" . |fromYaml) -}}
{{- if hasKey $allApiVersions $key -}}
{{ get $allApiVersions $key }}
{{- else -}}
{{- fail (printf "api version for object %s not defined in sylva-library" $key)}}
{{- end -}}
{{- end -}}

{{/*
This named template returns the apiGroup from the apiVersions for the resource passed in argument
*/}}

{{- define "getApiGroup" -}}
{{ regexSplit "/" ( include "getApiVersion" . ) -1 | first }}
{{- end -}}
