{{/*
This named template returns an error if the context passed in argument fails a check for any of:

- .cluster_virtual_ip is inside the subnet of .capm3.networks.primary.subnet, for empty .metallb.bgp_lbs and .kube_vip.bgp_lbs
- .cluster_virtual_ip is not equal to .capm3.networks.primary.gateway
- .cluster_virtual_ip is not inside the range defined by .capm3.networks.primary.start and .capm3.networks.primary.end
- .cluster_virtual_ipv6 (if set) is inside the subnet of .capm3.networks.primary.ipv6.subnet, for empty .metallb.bgp_lbs and .kube_vip.bgp_lbs
- .cluster_virtual_ipv6 (if set) is not equal to .capm3.networks.primary.ipv6.gateway
- .cluster_virtual_ipv6 (if set) is not inside the range defined by .capm3.networks.primary.ipv6.start and .capm3.networks.primary.ipv6.end
- if .ipv6_enabled is true, all .capm3.networks.foo must set ipv6 configuration

It can be used in parent charts like:

    * `sylva-capi-cluster` with:
        {{ tuple .Values | include "capm3NetworkValidation" }}

    * `sylva-units` with:
        {{- $envAll := set . "Values" (include "interpret-values-gotpl" . | fromJson) -}}
        {{ tuple $envAll.Values.cluster | include "capm3NetworkValidation" }}

*/}}
{{- define "capm3NetworkValidation" -}}
{{- $values := index . 0 -}}
    {{- $cluster_virtual_ip   := $values.cluster_virtual_ip -}}
    {{- $primary_pool_network := (regexSplit "/" $values.capm3.networks.primary.subnet -1 | first) -}}
    {{- $primary_pool_prefix  := (regexSplit "/" $values.capm3.networks.primary.subnet -1 | last) -}}
    {{- $primary_pool_start   := $values.capm3.networks.primary.start -}}
    {{- $primary_pool_end     := $values.capm3.networks.primary.end -}}
    {{- $primary_pool_gateway := $values.capm3.networks.primary.gateway | default "" -}}

    {{- $net_bits  := $primary_pool_prefix | atoi -}}

    {{- $cluster_virtual_ip_decimal   := tuple $cluster_virtual_ip   | include "get-ipv4-decimal" -}}
    {{- $primary_pool_network_decimal := tuple $primary_pool_network | include "get-ipv4-decimal" -}}

    {{/* checking .cluster_virtual_ip is inside the subnet of .capm3.networks.primary.subnet,
         skipping it if using BGP (.metallb.bgp_lbs or .kube_vip.bgp_lbs), and not ARP, for its advertisement */}}
    {{- if not (or ($values.metallb).bgp_lbs ($values.kube_vip).bgp_lbs) -}}
      {{/* we compare the most significant ($primary_pool_prefix) x bits, that define the network
           by formatting the IPv4 decimal representation to 32-bit binary string and truncating network bits */}}
      {{- $cluster_virtual_ip_net_bits   := trunc ($net_bits | int) ($cluster_virtual_ip_decimal   | atoi | printf "%032b") -}}
      {{- $primary_pool_network_net_bits := trunc ($net_bits | int) ($primary_pool_network_decimal | atoi | printf "%032b") -}}
      {{- if ne $cluster_virtual_ip_net_bits $primary_pool_network_net_bits -}}
        {{ fail (printf "The IP used to expose kube-api and LoadBalancer services (.cluster_virtual_ip) '%s' is not from subnet of .capm3.networks.primary.subnet '%s/%s'" $cluster_virtual_ip $primary_pool_network $primary_pool_prefix) }}
      {{- end -}}
    {{- end -}}

    {{/* checking .cluster_virtual_ip is not equal to .capm3.networks.primary.gateway */}}
    {{- if eq $cluster_virtual_ip $primary_pool_gateway -}}
      {{ fail (printf "The IP used to expose kube-api and LoadBalancer services (.cluster_virtual_ip) '%s' is also used as gateway for subnet of .capm3.networks.primary.subnet '%s/%s'" $cluster_virtual_ip $primary_pool_network $primary_pool_prefix) }}
    {{- end -}}

    {{/* checking .cluster_virtual_ip is outside of .capm3.networks.primary.start and .capm3.networks.primary.end range */}}
    {{/* OKD single node is an exception, its primary address will used be the .cluster_virtual_ip */}}
    {{- if and (eq $values.capi_providers.bootstrap_provider "cabpoa") (eq (int $values.control_plane_replicas) 1) -}}
      {{- $matchLabels := $values.control_plane.capm3.hostSelector.matchLabels }}
      {{- if eq (len $matchLabels) 0 }}
        {{ fail "[ERROR] control_plane.capm3.hostSelector.matchLabels is empty" }}
      {{- end }}
      {{- $found := false }}
      {{- range $name, $node := $values.baremetal_hosts }}
        {{- $labelMatches := true }}

        {{/* Check if all matchLabels are present in node labels with correct values */}}
        {{- range $labelKey, $labelValue := $matchLabels }}
          {{- if ne (index $node.bmh_metadata.labels $labelKey) $labelValue }}
            {{- $labelMatches = false }}
            {{- break }}
          {{- end }}
        {{- end }}
        {{- if and $labelMatches (eq $node.ip_preallocations.primary $cluster_virtual_ip) }}
          {{- $found = true }}
          {{- break }}
        {{- end }}
      {{- end }}
      {{- if not $found }}
        {{ fail (printf "'cluster_virtual_ip' for single node OKD/OpenShift cluster should be the same as the node primary ip address and 'control_plane' needs to have label matching baremetal_host") }}
      {{ end }}
    {{- else -}}
      {{- $primary_pool_start_decimal := tuple $primary_pool_start | include "get-ipv4-decimal" -}}
      {{- $primary_pool_end_decimal   := tuple $primary_pool_end   | include "get-ipv4-decimal" -}}
      {{- if and (ge $cluster_virtual_ip_decimal $primary_pool_start_decimal)
                 (le $cluster_virtual_ip_decimal $primary_pool_end_decimal) -}}
        {{ fail (printf "The IP used to expose kube-api and LoadBalancer services (.cluster_virtual_ip) '%s' is inside the range of .capm3.networks.primary.start/.end '%s-%s'. This is wrong, as it may be allocated to a baremetal node." $cluster_virtual_ip $primary_pool_start $primary_pool_end) }}
      {{- end -}}
    {{- end -}}

    {{- if $values.ipv6_enabled -}}
      {{/* Check that all defined networks have IPv6 definitions */}}
      {{- $missing_ipv6 := list -}}
      {{- range $network_name, $network_def := $values.capm3.networks -}}
        {{- if not $network_def.ipv6 -}}
          {{- $missing_ipv6 = append $missing_ipv6 $network_name -}}
        {{- end -}}
      {{- end -}}
      {{- if gt (len $missing_ipv6) 0 -}}
        {{ fail (printf "ipv6_enabled is set to true, so all capm3 networks must have ipv6 definitions. Missing for the network(s): %s" ($missing_ipv6 | toStrings)) }}
      {{- end -}}

      {{- $primary_pool_v6_network := (regexSplit "/" $values.capm3.networks.primary.ipv6.subnet -1 | first) -}}
      {{- $primary_pool_v6_prefix  := (regexSplit "/" $values.capm3.networks.primary.ipv6.subnet -1 | last) -}}
      {{- $primary_pool_v6_start   := $values.capm3.networks.primary.ipv6.start -}}
      {{- $primary_pool_v6_end     := $values.capm3.networks.primary.ipv6.end -}}
      {{- $primary_pool_v6_gateway := $values.capm3.networks.primary.ipv6.gateway | default "" -}}
      {{- $net_bits_v6 := $primary_pool_v6_prefix | atoi -}}

      {{- $primary_pool_v6_network_bin := tuple $primary_pool_v6_network | include "get-ipv6-binary" -}}
      {{- $primary_pool_v6_start_bin := tuple $primary_pool_v6_start | include "get-ipv6-binary" -}}
      {{- $primary_pool_v6_end_bin   := tuple $primary_pool_v6_end   | include "get-ipv6-binary" -}}

      {{- range $bmh_name, $bmh_spec := $values.baremetal_hosts -}}
        {{- if $bmh_spec.ip_preallocations_v6 -}}
          {{- range $network, $preallocation := $bmh_spec.ip_preallocations_v6 -}}
            {{/* Check that the network of the ip_preallocations_v6 has ipv6 definition */}}
            {{- if not ($values.capm3.networks | dig $network "ipv6" false) -}}
              {{ fail (printf "The network '%s' specified in ip_preallocations_v6 for baremetal host '%s' is missing the IPv6 definition" $network $bmh_name) }}
            {{- end -}}
            {{/* Check that the ip_preallocation is inside the network subnet */}}
            {{- $netcheck_start_bin := tuple ($values.capm3.networks | dig $network "ipv6" "start" "") | include "get-ipv6-binary" -}}
            {{- $netcheck_end_bin := tuple ($values.capm3.networks | dig $network "ipv6" "end" "") | include "get-ipv6-binary" -}}
            {{- $ip_preallocation_bin := tuple $preallocation | include "get-ipv6-binary" -}}
            {{- if not (and (ge $ip_preallocation_bin $netcheck_start_bin)
                            (le $ip_preallocation_bin $netcheck_end_bin)) -}}
              {{ fail (printf "The ip preallocation '%s' used for baremetal host '%s' is not inside the range defined for network '%s'." $preallocation $bmh_name $network) }}
            {{- end -}}
          {{- end -}}
        {{- end -}}
      {{- end -}}

      {{/* .cluster_virtual_ipv6 is optional -- dual-stack VIP checks only run when it's set */}}
      {{- if $values.cluster_virtual_ipv6 -}}
        {{- $cluster_virtual_ip_v6   := $values.cluster_virtual_ipv6 -}}
        {{- $cluster_virtual_ip_v6_bin   := tuple $cluster_virtual_ip_v6   | include "get-ipv6-binary" -}}
  
        {{/* checking .cluster_virtual_ipv6 is not equal to .capm3.networks.primary.ipv6.gateway */}}
        {{- if eq $cluster_virtual_ip_v6 $primary_pool_v6_gateway -}}
          {{ fail (printf "The IP used to expose kube-api and LoadBalancer services (.cluster_virtual_ipv6) '%s' is also used as gateway for subnet of .capm3.networks.primary.ipv6.subnet '%s/%s'" $cluster_virtual_ip_v6 $primary_pool_v6_network $primary_pool_v6_prefix) }}
        {{- end -}}
  
        {{/* checking .cluster_virtual_ipv6 is inside the subnet of .capm3.networks.primary.ipv6.subnet,
             skipping it if using BGP (.metallb.bgp_lbs or .kube_vip.bgp_lbs), and not ARP, for its advertisement */}}
        {{- if not (or ($values.metallb).bgp_lbs ($values.kube_vip).bgp_lbs) -}}
          {{/* same trunc-of-binary-string comparison as IPv4, just on a 128-bit string instead of 32 */}}
          {{- $cluster_virtual_ip_v6_net_bits   := trunc ($net_bits_v6 | int) $cluster_virtual_ip_v6_bin -}}
          {{- $primary_pool_v6_network_net_bits := trunc ($net_bits_v6 | int) $primary_pool_v6_network_bin -}}
          {{- if ne $cluster_virtual_ip_v6_net_bits $primary_pool_v6_network_net_bits -}}
            {{ fail (printf "The IPv6 address used to expose kube-api and LoadBalancer services (.cluster_virtual_ipv6) '%s' is not from subnet of .capm3.networks.primary.ipv6.subnet '%s/%s'" $cluster_virtual_ip_v6 $primary_pool_v6_network $primary_pool_v6_prefix) }}
          {{- end -}}
        {{- end -}}
        {{/* checking .cluster_virtual_ipv6 is outside of .capm3.networks.primary.ipv6.start/.end range */}}
        {{- if and (ge $cluster_virtual_ip_v6_bin $primary_pool_v6_start_bin)
                   (le $cluster_virtual_ip_v6_bin $primary_pool_v6_end_bin) -}}
          {{ fail (printf "The IPv6 address used to expose kube-api and LoadBalancer services (.cluster_virtual_ipv6) '%s' is inside the range of .capm3.networks.primary.ipv6.start/.end '%s-%s'. This is wrong, as it may be allocated to a baremetal node." $cluster_virtual_ip_v6 $primary_pool_v6_start $primary_pool_v6_end) }}
        {{- end -}}
      {{- end -}}
    {{- end -}}
{{- end -}}

{{/*
For an input IPv4 address represented in binary string, dotted decimal format A.B.C.D,
compute its 32-bit integer decimal representation, using the formula:
A * 16777216 (2 power 24) + B * 65536 (2 power 16) + C * 256 (2 power 8) + D * 1 (2 power 0)

Template:

{{- include "get-ipv4-decimal" 192.168.130.30 }}

Result:

3,232,268,830

*/}}
{{- define "get-ipv4-decimal" -}}
  {{- $ipv4 := index . 0 -}}
  {{- $ipv4_octets := $ipv4 | split "." -}}
  {{- add
      (($ipv4_octets._0 | atoi) | mul 16777216)
      (($ipv4_octets._1 | atoi) | mul 65536)
      (($ipv4_octets._2 | atoi) | mul 256)
       ($ipv4_octets._3 | atoi)
  -}}

{{- end -}}

{{/*
For an input IPv6 address (RFC 5952 form, "::" compression and omitted leading
zeros allowed), compute its full 128-bit binary string representation.
Unlike get-ipv4-decimal, this never converts to a decimal integer -- IPv6
addresses don't fit in Sprig's int64 arithmetic -- it builds the binary string
directly from hex nibbles instead. The result is always exactly 128 characters,
which is what lets the caller reuse `trunc`/`ne`/`ge`/`le` on it exactly like
the IPv4 32-bit binary string.

Template:

{{- include "get-ipv6-binary" "fd00:130::1" }}

Result: (128-char string of 0s/1s)

*/}}
{{- define "get-ipv6-binary" -}}
  {{- $ipv6 := index . 0 | lower -}}
  {{- $nibble_bits := dict
      "0" "0000" "1" "0001" "2" "0010" "3" "0011"
      "4" "0100" "5" "0101" "6" "0110" "7" "0111"
      "8" "1000" "9" "1001" "a" "1010" "b" "1011"
      "c" "1100" "d" "1101" "e" "1110" "f" "1111" -}}
  {{- $groups := list -}}
  {{- if contains "::" $ipv6 -}}
    {{- $parts := splitn "::" 2 $ipv6 -}}
    {{- $left  := ternary (list) (splitList ":" $parts._0) (eq $parts._0 "") -}}
    {{- $right := ternary (list) (splitList ":" $parts._1) (eq $parts._1 "") -}}
    {{- $missing := sub 8 (add (len $left) (len $right)) -}}
    {{- range $left }}{{- $groups = append $groups . -}}{{- end -}}
    {{- range $i := until ($missing | int) }}{{- $groups = append $groups "0" -}}{{- end -}}
    {{- range $right }}{{- $groups = append $groups . -}}{{- end -}}
  {{- else -}}
    {{- $groups = splitList ":" $ipv6 -}}
  {{- end -}}
  {{- $bits := "" -}}
  {{- range $group := $groups -}}
    {{- $chars := splitList "" $group -}}
    {{- range $i := until (sub 4 (len $chars) | int) }}{{- $bits = print $bits "0000" -}}{{- end -}}
    {{- range $c := $chars }}{{- $bits = print $bits (index $nibble_bits $c) -}}{{- end -}}
  {{- end -}}
  {{- $bits -}}
{{- end -}}

{{/* Calculate interface mtu from different levels */}}
{{- define "calculate-mtu" -}}
  {{- $envAll := index . 0 -}}
  {{- $interface_name := index . 1 -}}
  {{- $interface_def := index . 2 -}}
  {{- $networks := index . 3 -}}
  {{- $interfaces := index . 4 -}}
  {{- $interface_mtu := $envAll.Values.capm3.default_network_settings.mtu -}}
  {{- $parent_mtu := "" -}}

  {{/* If the interface is a vlan, check if the mtu is specified at interface.vlans[X] level */}}
  {{- $vlan_interface := $interface_name | split "." -}}
  {{- $vlan_interface_mtu := dict -}}
  {{- if $vlan_interface._1 -}}
    {{- range $vlan := ($interfaces | dig $vlan_interface._0 "vlans" list) -}}
      {{- if and (eq ($vlan.id | toString) $vlan_interface._1) $vlan.mtu -}}
        {{- $_ := set $vlan_interface_mtu "mtu" $vlan.mtu -}}
      {{- end -}}
    {{- end -}}
  {{- end }}        
  
  {{- range $network_name, $network_def := $networks -}}
    {{- if eq $interface_name $network_def.interface -}}
       {{- $interface_mtu = max $interface_mtu (pluck "mtu" $envAll.Values.capm3.default_network_settings $network_def $interface_def $vlan_interface_mtu | last) -}}
    {{- else -}}
       {{- $interface_mtu = max $interface_mtu (pluck "mtu" $envAll.Values.capm3.default_network_settings $interface_def $vlan_interface_mtu | last) -}}
    {{- end -}}
  {{- end -}}

  {{/* If the interface is part of a bond set the mtu to the bond mtu */}}
  {{- if eq $interface_def.type "phy" -}}
    {{- range $other_iface_name, $other_iface_def := $interfaces -}}
      {{- if and (eq $other_iface_def.type "bond") ($other_iface_def.interfaces | has $interface_name) -}}
        {{- $interface_mtu = tuple $envAll $other_iface_name $other_iface_def $networks $interfaces | include "calculate-mtu" -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}

  {{/* If the interface has vlans attached adjust to the maximum mtu of the vlans */}}
  {{- if hasKey $interface_def "vlans" -}}
  {{- $vlan_mtu := 0 -}}
    {{- range $vlan := $interface_def.vlans -}}
      {{- $vlan_name := printf "%s.%s" $interface_name ($vlan.id | toString) -}}
      {{- $vlan_mtu = tuple $envAll $vlan_name (omit $interface_def "vlans" "mtu") $networks $interfaces | include "calculate-mtu" -}}
      {{- $interface_mtu = max $interface_mtu $vlan_mtu -}}
    {{- end -}}
  {{- end -}}

{{ $interface_mtu }}
{{- end -}}

{{- /* This function retrieves the matching cp/md definition for a given bmh (according to labels)
It takes as parameter:
 - complete cluster definition (typically $envAll)
 - curent bmh name
 - current bmh definition
It will fail if:
 - no match is found
 - more than one cp/md matches
*/}}
{{- define "getMatchingValuesDefinitionForBmh" }}
{{- $envAll := index . 0 -}}
{{- $bmh_name := index . 1 -}}
{{- $bmh_values := index . 2 -}}

{{- $matching_machine_group_values := dict }}
{{- $machine_groups := dict "control-plane" $envAll.Values.control_plane }}
{{- range $md_name, $md_values := $envAll.Values.machine_deployments }}
    {{- $md_merged_values := mergeOverwrite (deepCopy $envAll.Values.machine_deployment_default) $md_values }}
    {{- $machine_groups = merge $machine_groups (dict $md_name $md_merged_values) }}
{{- end }}

{{- range $machine_group_name, $machine_group_values := $machine_groups }}
  {{- $label_matches := 0 }}
  {{- range $label_key, $label_value := $machine_group_values.capm3.hostSelector.matchLabels }}
    {{- if (eq (dig "bmh_metadata" "labels" $label_key "" $bmh_values) $label_value) }}
      {{- $label_matches = add1 $label_matches }}
    {{- end }}
  {{- end }}
  {{- if eq $label_matches (len $machine_group_values.capm3.hostSelector.matchLabels) }}
    {{- if gt (len $matching_machine_group_values) 0 }}
      {{ printf "[ERROR] Multiple cp/md have hostSelector matching baremetalhost '%s'" $bmh_name | fail }}
    {{- else }}
      {{- $matching_machine_group_values = $machine_group_values }}
      {{- $_ := set $matching_machine_group_values "machineGroupName" $machine_group_name }}
    {{- end }}
  {{- end }}
{{- end }}
{{ if not $matching_machine_group_values }}
  {{ printf "[ERROR] Unable to find cp/md definition for baremetalhost %s" $bmh_name | fail }}
{{- end }}
{{- $_ := set $matching_machine_group_values "capm3" (mergeOverwrite (deepCopy $envAll.Values.capm3) (deepCopy $matching_machine_group_values.capm3)) }}
{{- $matching_machine_group_values | toJson -}}
{{- end }}

{{/*
This named template validates BMH spec configuration.

It checks that the 'online' field is not present in bmh_spec (it's now managed by operators).

It can be used in parent charts like:

    * `sylva-capi-cluster` with:
        {{ tuple .Values | include "bmhSpecValidation" }}

    * `sylva-units` with:
        {{- $envAll := set . "Values" (include "interpret-values-gotpl" . | fromJson) -}}
        {{ tuple $envAll.Values.cluster | include "bmhSpecValidation" }}

*/}}
{{- define "bmhSpecValidation" -}}
{{- $values := index . 0 -}}

    {{/* Check baremetal_host_default for 'online' field */}}
    {{- if and $values.baremetal_host_default $values.baremetal_host_default.bmh_spec -}}
      {{- if hasKey $values.baremetal_host_default.bmh_spec "online" -}}
        {{- fail "\n\n========================================\nERROR: Invalid bmh_spec configuration\n========================================\n\nThe 'online' field in 'baremetal_host_default.bmh_spec' is no longer supported and must be removed.\n\nREASON:\n  The 'online' field is now managed automatically by the BareMetal and Metal3 operators.\n  Manual configuration of this field can cause conflicts with the operator's management.\n\nACTION REQUIRED:\n  Please remove the 'online' field from 'baremetal_host_default.bmh_spec' in your configuration.\n========================================\n" -}}
      {{- end -}}
    {{- end -}}

    {{/* Check each baremetal_host for 'online' field */}}
    {{- range $hostName, $host := $values.baremetal_hosts -}}
      {{- if and $host.bmh_spec (hasKey $host.bmh_spec "online") -}}
        {{- fail (printf "\n\n========================================\nERROR: Invalid bmh_spec configuration\n========================================\n\nThe 'online' field in 'baremetal_hosts.%s.bmh_spec' is no longer supported and must be removed.\n\nREASON:\n  The 'online' field is now managed automatically by the BareMetal and Metal3 operators.\n  Manual configuration of this field can cause conflicts with the operator's management.\n\nACTION REQUIRED:\n  Please remove the 'online' field from 'baremetal_hosts.%s.bmh_spec' in your configuration.\n========================================\n" $hostName $hostName) -}}
      {{- end -}}
    {{- end -}}

{{- end -}}
