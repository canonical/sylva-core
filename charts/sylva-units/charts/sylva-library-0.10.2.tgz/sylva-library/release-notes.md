# Merge Requests integrated in this release

3 merge requests were integrated in this repo between 0.10.1 and 0.10.2.
These notes don't account for the MRs merged in secondary repos.

## Networking

* Add ipv6 vip validation [\!168](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/168) ~"type::feature" (issues: [\#10](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/issues/10))

## CI

* Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.1.5 ~"renovate" [\!169](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/169) [\!170](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/170)

## Contributors

1 person contributed.

[Cristian Manda](https://gitlab.com/cristian.manda)
