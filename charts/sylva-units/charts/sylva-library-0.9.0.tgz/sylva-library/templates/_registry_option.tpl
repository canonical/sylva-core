{{- define "registry_mirrors" -}}
  {{- $envAll := index . 0 -}}
  {{- $type := index . 1 | default "" -}}
  {{- $index := 0 -}}
  {{- $registryMirrors := get $envAll.Values "registry_mirrors" | default dict -}}
  {{- $defaultSettings := get $registryMirrors "default_settings" | default dict -}}
  {{- $mirrorSettings := dict -}}
  {{- range $registry, $mirrors := get $registryMirrors "hosts_config" | default dict }}
    {{- $registryUrl := printf "https://%s" $registry }}
    {{- $defaultMirror := $registryUrl }}
    {{- $defaultMirrorFound := false }}
    {{- range $_, $config := $mirrors }}
      {{- $mirrorSettings = set $mirrorSettings $config.mirror_url (mergeOverwrite (deepCopy $defaultSettings) (deepCopy (get $config "registry_settings" | default dict))) }}
      {{- if get $config "is_default_mirror" }}
          {{- if $defaultMirrorFound }}
            {{- fail (printf "Error: More than one default mirror found for registry '%s'" $registry) }}
          {{- end }}
          {{- $defaultMirror = $config.mirror_url }}
          {{- $defaultMirrorFound = true }}
      {{- end }}
    {{- end }}
    {{- if eq $type "kind" -}}
mkdir -p $KIND_CONFIG_DIRECTORY/{{ $registry }}
cat << EOF{{ $index }} > $KIND_CONFIG_DIRECTORY/{{ $registry }}/hosts.toml
server = "{{ $defaultMirror }}"
{{- if $defaultMirrorFound }}
  {{- range $setting, $value := get $mirrorSettings $defaultMirror }}
{{ $setting }} = {{ $value | toJson }}
  {{- end -}}
{{- end -}}
{{- range $_, $config := $mirrors }}
[host."{{ $config.mirror_url }}"]
{{- range $setting,$value := get $mirrorSettings $config.mirror_url }}
  {{ $setting }} = {{ $value | toJson }}
{{- end -}}
{{- end }}
EOF{{ $index }}
{{- println -}}
{{- $index = add1 $index -}}
    {{- else -}}
- path: /etc/containerd/registry.d/{{ $registry }}/hosts.toml
  owner: root
  permissions: "0644"
  content: |
    server = "{{ $defaultMirror }}"
    {{- if $defaultMirrorFound }}
      {{- range $setting, $value := get $mirrorSettings $defaultMirror }}
    {{ $setting }} = {{ $value | toJson }}
      {{- end -}}
    {{- end -}}
    {{- range $_, $config := $mirrors }}
    [host."{{ $config.mirror_url }}"]
    {{- range $setting,$value := get $mirrorSettings $config.mirror_url }}
      {{ $setting }} = {{ $value | toJson }}
    {{- end }}
    {{- end }}
    {{- end -}}
    {{- println "" }}
  {{- end -}}
{{- end -}}
