{{- define "adv-pool-validation" -}}
{{- $bgp_lbs := index . 0 -}}
  {{- if ($bgp_lbs | dig "l3_options" "bgp_peers" false) -}}
    {{/* Check each peer for 'advertised_pools' field */}}

    {{- range $peer_name, $peer_def := $bgp_lbs.l3_options.bgp_peers -}}
      {{- if hasKey $peer_def "advertised_pools" -}}
        {{- fail (printf "\n\n========================================\nERROR: Invalid bgp peer configuration\n========================================\n\nThe 'advertised_pools' field in 'bgp_peers' is no longer supported and must be removed.\n\nREASON:\n  The coupling between bgp peers and advertised pools is now controlled via bgp_advertisements.\n\nACTION REQUIRED:\n  Please remove the 'advertised_pools' field from 'bgp_peers.%s' in your configuration.\n========================================\n" $peer_name) -}}
      {{- end -}}
    {{- end -}}
  {{- end -}}
{{- end -}}

