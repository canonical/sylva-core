# Merge Requests integrated in this release

2 merge requests were integrated in this repo between 0.8.4 and 0.9.0.
These notes don't account for the MRs merged in secondary repos.

## Other

* Add settings on default mirrors [\!161](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/161) 

## CI

* Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.1.2 [\!159](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/159) ~"renovate"

## Contributors

1 person contributed.

[Remi Le Trocquer](https://gitlab.com/rletrocquer)
