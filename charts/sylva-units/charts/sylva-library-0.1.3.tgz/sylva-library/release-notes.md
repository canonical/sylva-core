# Merge Requests integrated in this release

## CI

* Update dependency to-be-continuous/gitleaks to v2.6.1 [#38](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/38) ~"CI" ~"renovate"
* update readme, add ci job forbidden-filename and gitignore [#43](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/43) ~"CI" ~"CI::linter"

## Other

* Fix capm3NetworkValidation template for missing [metallb|kube\_vip].bgp\_lbs values [#42](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/42) 

## Contributors

[francois klieber](https://gitlab.com/FrancoisKlieberOrange), [Bogdan-Adrian Burciu](https://gitlab.com/baburciu)
