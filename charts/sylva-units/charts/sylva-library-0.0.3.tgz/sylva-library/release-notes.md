# New MRs

## CAPO

* MR: [Update openstackcluster and openstackmachinetemplate apiversion to v1beta1](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/25) ~capo

## CI

* MR: [Update dependency renovate-bot/renovate-runner to v18.16.4](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/24) ~CI ~renovate
* MR: [Update dependency renovate-bot/renovate-runner to v18.7.0](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/23) ~CI ~renovate

## Contributors

Bogdan-Adrian Burciu, Sylva Renovate bot
