# New MRs

## CI

* MR: [Update dependency renovate-bot/renovate-runner to v18](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/21) ~CI ~renovate

## Other

* MR: [Add apiversion for okd controlplane](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/22) 

## Contributors

Sylva Renovate bot, Jianzhu Zhang
