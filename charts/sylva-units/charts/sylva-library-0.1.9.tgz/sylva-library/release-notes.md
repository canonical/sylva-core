# Merge Requests integrated in this release

## OKD/OpenShift

* OpenShift CAPI crd name change [!59](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/59) 

## CI

* <details><summary>Update dependency renovate-bot/renovate-runner to v19.28.1</summary>

  * Update dependency renovate-bot/renovate-runner to v19 [!64](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/64) ~"renovate"

  * Update dependency renovate-bot/renovate-runner to v19.10.1 [!65](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/65) ~"renovate"

  * Update dependency renovate-bot/renovate-runner to v19.19.0 [!67](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/67) ~"renovate"

  * Update dependency renovate-bot/renovate-runner to v19.28.1 [!69](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/69) ~"renovate"
</details>

* <details><summary>Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.31</summary>

  * Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.30 [!68](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/68) ~"renovate"

  * Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.31 [!70](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/70) ~"renovate"
</details>


## Contributors

[Jianzhu Zhang](https://gitlab.com/jianzzha)
