# Merge Requests integrated in this release

## CAPM3

* Update fields for network refactoring and add a "calculate-mtu" template [!77](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/77) 

## CI

* <details><summary>Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.39</summary>

  * Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.38 [!98](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/98) ~"renovate"

  * Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.39 [!102](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/102) ~"renovate"
</details>


## Contributors

[Cristian Manda](https://gitlab.com/cristian.manda)
