# Merge Requests integrated in this release

4 merge requests were integrated in this repo between 0.3.5 and 0.3.8.
These notes don't account for the MRs merged in secondary repos.

## Baremetal ~capm3

* [backport sylva 1.4 / 0.3] Correct network field names [\!151](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/151) ~"backport"

## CI

* Update dependency sylva-projects/sylva-elements/ci-tooling/ci-templates to v1.0.43 ~"renovate" [\!120](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/120) [\!122](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/122) [\!125](https://gitlab.com/sylva-projects/sylva-elements/helm-charts/sylva-library/-/merge_requests/125)

## Contributors

1 person contributed.

[Priya Goyal](https://gitlab.com/priyagoyal)
